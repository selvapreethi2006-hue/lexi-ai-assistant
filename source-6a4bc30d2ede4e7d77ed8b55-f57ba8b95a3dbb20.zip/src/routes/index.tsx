import { FormEvent, useMemo, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { motion } from 'framer-motion'
import toast, { Toaster } from 'react-hot-toast'
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from 'recharts'
import {
  AlertTriangle,
  BookOpen,
  Bot,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  FileCheck2,
  FileText,
  Gavel,
  Languages,
  LayoutDashboard,
  LockKeyhole,
  Mail,
  Mic,
  Moon,
  PenLine,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  UploadCloud,
  UserRound,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

const disclaimer =
  'LexiAI provides informational assistance only and is not a substitute for advice from a qualified lawyer.'

const features: Array<{ title: string; text: string; Icon: LucideIcon }> = [
  { title: 'Document intelligence', text: 'Summaries, dates, parties, duties, rights, and action items from uploaded contracts.', Icon: FileText },
  { title: 'Agentic risk review', text: 'Clause detection for payment, liability, arbitration, renewal, jurisdiction, and penalties.', Icon: AlertTriangle },
  { title: 'Guided legal drafting', text: 'Rental agreements, NDAs, notices, affidavits, employment agreements, and wills.', Icon: PenLine },
  { title: 'Research workspace', text: 'Search legal topics, save bookmarks, and connect answers to document context.', Icon: BookOpen },
]

const stats = [
  ['18.4k', 'documents reviewed'],
  ['6.7 min', 'median first summary'],
  ['42', 'supported legal workflows'],
  ['12', 'language modes'],
]

const activity = [
  'Rental agreement summary generated',
  'High-risk liability clause flagged',
  'Court-date reminder scheduled',
  'NDA draft exported to DOCX',
]

const chartData = [
  { month: 'Jan', docs: 24, risks: 9 },
  { month: 'Feb', docs: 38, risks: 13 },
  { month: 'Mar', docs: 45, risks: 15 },
  { month: 'Apr', docs: 57, risks: 18 },
  { month: 'May', docs: 73, risks: 21 },
  { month: 'Jun', docs: 88, risks: 26 },
]

const agents = [
  'Planner Agent',
  'Document Agent',
  'Research Agent',
  'Risk Analysis Agent',
  'Drafting Agent',
  'Explanation Agent',
  'Memory Agent',
  'Response Agent',
]

const documents = [
  { name: 'Commercial Lease.pdf', risk: 78, status: 'Risk review ready' },
  { name: 'Employment Offer.docx', risk: 34, status: 'Summary complete' },
  { name: 'Vendor NDA.pdf', risk: 51, status: 'Missing clauses found' },
]

const clauses = [
  ['Termination', 'Notice period is one-sided and may allow abrupt cancellation.', 'High'],
  ['Payment', 'Late fee language is present but lacks grace-period detail.', 'Medium'],
  ['Jurisdiction', 'Forum selection appears outside the user profile location.', 'Medium'],
  ['Confidentiality', 'Scope is clear, but survival period should be capped.', 'Low'],
]

function LegalDisclaimer() {
  return (
    <div className="rounded-2xl border border-amber-300/70 bg-amber-50/90 px-4 py-3 text-sm font-medium text-amber-950 shadow-sm dark:border-amber-500/40 dark:bg-amber-400/10 dark:text-amber-100">
      <ShieldCheck className="mr-2 inline h-4 w-4" aria-hidden="true" />
      {disclaimer}
    </div>
  )
}

function SectionTitle({ eyebrow, title, text }: { eyebrow: string; title: string; text: string }) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      <p className="text-sm font-semibold uppercase tracking-[0.28em] text-amber-600">{eyebrow}</p>
      <h2 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950 dark:text-white sm:text-4xl">{title}</h2>
      <p className="mt-4 text-base leading-7 text-slate-600 dark:text-slate-300">{text}</p>
    </div>
  )
}

function App() {
  const [message, setMessage] = useState('')
  const [theme, setTheme] = useState<'light' | 'dark'>('light')
  const [activeDoc, setActiveDoc] = useState(documents[0])
  const [chat, setChat] = useState([
    { from: 'assistant', text: 'Upload a document or ask a legal question. I can summarize, explain clauses, draft documents, and identify risk.' },
  ])

  const shellClass = useMemo(() => (theme === 'dark' ? 'dark' : ''), [theme])

  function submitChat(event: FormEvent) {
    event.preventDefault()
    if (!message.trim()) return
    setChat((items) => [
      ...items,
      { from: 'user', text: message },
      {
        from: 'assistant',
        text: 'Planner Agent routed this to Document, Risk, Research, and Response agents. Preliminary view: define parties, deadlines, fees, termination rights, and dispute venue before signing.',
      },
    ])
    setMessage('')
    toast.success('AI legal guidance prepared')
  }

  return (
    <div className={shellClass}>
      <main className="min-h-screen bg-[#F8FAFC] text-slate-950 dark:bg-[#07111f] dark:text-white">
        <Toaster position="top-right" />
        <div className="fixed inset-0 -z-0 overflow-hidden">
          <div className="absolute left-[-12%] top-[-10%] h-96 w-96 rounded-full bg-blue-200/50 blur-3xl dark:bg-blue-500/10" />
          <div className="absolute right-[-8%] top-36 h-80 w-80 rounded-full bg-amber-200/60 blur-3xl dark:bg-amber-500/10" />
          <div className="absolute inset-0 bg-[linear-gradient(rgba(30,58,138,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(30,58,138,0.06)_1px,transparent_1px)] bg-[size:42px_42px]" />
        </div>

        <nav className="sticky top-0 z-40 border-b border-white/40 bg-white/70 backdrop-blur-2xl dark:border-white/10 dark:bg-slate-950/70">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
            <a href="#home" className="flex items-center gap-3 font-semibold" aria-label="LexiAI home">
              <span className="grid h-10 w-10 place-items-center rounded-2xl bg-[#1E3A8A] text-white shadow-lg shadow-blue-900/20">
                <Gavel className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="text-xl">LexiAI</span>
            </a>
            <div className="hidden items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300 lg:flex">
              {['Dashboard', 'Chat', 'Documents', 'Research', 'Admin'].map((item) => (
                <a key={item} href={`#${item.toLowerCase()}`} className="hover:text-[#2563EB]">
                  {item}
                </a>
              ))}
            </div>
            <div className="flex items-center gap-2">
              <button
                aria-label="Toggle dark mode"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="rounded-full border border-slate-200 bg-white p-3 shadow-sm dark:border-white/10 dark:bg-white/10"
              >
                <Moon className="h-4 w-4" />
              </button>
              <a href="#login" className="rounded-full bg-[#1E3A8A] px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-900/20">
                Sign in
              </a>
            </div>
          </div>
        </nav>

        <section id="home" className="relative mx-auto grid max-w-7xl gap-8 px-5 pb-16 pt-10 lg:grid-cols-[0.95fr_1.05fr] lg:pt-16">
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="space-y-8">
            <LegalDisclaimer />
            <div>
              <p className="mb-4 inline-flex rounded-full border border-blue-200 bg-white/80 px-4 py-2 text-sm font-semibold text-[#1E3A8A] shadow-sm dark:border-blue-400/20 dark:bg-white/10 dark:text-blue-200">
                Agentic AI Legal Assistant
              </p>
              <h1 className="text-5xl font-semibold tracking-tight text-slate-950 dark:text-white sm:text-6xl lg:text-7xl">
                Understand Legal Documents. Get AI Guidance. Stay Informed.
              </h1>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600 dark:text-slate-300">
                LexiAI combines document intelligence, RAG research, risk analysis, drafting, multilingual explanations, reminders, and secure history into one polished legal-information workspace.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <a href="#chat" className="inline-flex items-center gap-2 rounded-full bg-[#2563EB] px-6 py-4 font-semibold text-white shadow-xl shadow-blue-700/20">
                Ask LexiAI <ChevronRight className="h-4 w-4" />
              </a>
              <a href="#documents" className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white/80 px-6 py-4 font-semibold text-slate-900 shadow-sm dark:border-white/10 dark:bg-white/10 dark:text-white">
                Upload document <UploadCloud className="h-4 w-4" />
              </a>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {stats.map(([value, label]) => (
                <div key={label} className="rounded-2xl border border-white/70 bg-white/80 p-4 shadow-sm backdrop-blur dark:border-white/10 dark:bg-white/10">
                  <div className="text-2xl font-semibold text-[#1E3A8A] dark:text-blue-200">{value}</div>
                  <div className="mt-1 text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7 }} className="rounded-[2rem] border border-white/80 bg-white/75 p-4 shadow-2xl shadow-blue-950/10 backdrop-blur-2xl dark:border-white/10 dark:bg-white/10">
            <div className="grid gap-4 lg:grid-cols-[0.8fr_1.2fr]">
              <aside className="rounded-3xl bg-slate-950 p-4 text-white">
                <div className="flex items-center gap-3">
                  <Bot className="h-5 w-5 text-amber-300" />
                  <span className="font-semibold">Agent Router</span>
                </div>
                <div className="mt-5 space-y-3">
                  {agents.map((agent, index) => (
                    <div key={agent} className="flex items-center justify-between rounded-2xl bg-white/8 px-3 py-3 text-sm">
                      <span>{agent}</span>
                      <span className={index < 4 ? 'text-amber-300' : 'text-blue-200'}>{index < 4 ? 'active' : 'ready'}</span>
                    </div>
                  ))}
                </div>
              </aside>
              <div className="space-y-4">
                <div className="rounded-3xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-slate-950/70">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-sm font-semibold text-slate-500">Contract Analyzer</p>
                      <h3 className="mt-1 text-2xl font-semibold">{activeDoc.name}</h3>
                    </div>
                    <span className="rounded-full bg-amber-100 px-3 py-1 text-sm font-semibold text-amber-900">{activeDoc.risk}% risk</span>
                  </div>
                  <div className="mt-5 h-3 rounded-full bg-slate-100 dark:bg-white/10">
                    <div className="h-3 rounded-full bg-gradient-to-r from-[#2563EB] to-[#F59E0B]" style={{ width: `${activeDoc.risk}%` }} />
                  </div>
                  <div className="mt-5 grid gap-3 sm:grid-cols-2">
                    {clauses.map(([name, note, risk]) => (
                      <div key={name} className="rounded-2xl border border-slate-100 bg-slate-50 p-3 dark:border-white/10 dark:bg-white/5">
                        <div className="flex items-center justify-between text-sm font-semibold">
                          <span>{name}</span>
                          <span className="text-amber-600">{risk}</span>
                        </div>
                        <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{note}</p>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  {documents.map((doc) => (
                    <button key={doc.name} onClick={() => setActiveDoc(doc)} className="rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-1 hover:shadow-lg dark:border-white/10 dark:bg-white/10">
                      <FileCheck2 className="h-5 w-5 text-[#2563EB]" />
                      <p className="mt-3 text-sm font-semibold">{doc.name}</p>
                      <p className="mt-1 text-xs text-slate-500">{doc.status}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        <section id="features" className="mx-auto max-w-7xl px-5 py-16">
          <SectionTitle eyebrow="Complete workspace" title="Everything a modern legal assistant needs" text="A single responsive product surface for uploads, OCR, summaries, risk scoring, drafting, research, reminders, saved chats, profile controls, and admin operations." />
          <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {features.map(({ title, text, Icon }) => (
              <motion.div whileHover={{ y: -6 }} key={title} className="rounded-3xl border border-white/80 bg-white p-6 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
                <Icon className="h-7 w-7 text-[#2563EB]" />
                <h3 className="mt-5 text-xl font-semibold">{title}</h3>
                <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">{text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        <section id="dashboard" className="mx-auto grid max-w-7xl gap-5 px-5 py-16 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="rounded-3xl border border-white/80 bg-white p-6 shadow-xl shadow-slate-200/60 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
            <div className="flex items-center gap-3">
              <LayoutDashboard className="h-6 w-6 text-[#2563EB]" />
              <h2 className="text-2xl font-semibold">Dashboard Overview</h2>
            </div>
            <div className="mt-6 h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="docs" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#2563EB" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#2563EB" stopOpacity={0.02} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(100,116,139,.2)" />
                  <XAxis dataKey="month" stroke="#64748b" />
                  <Tooltip />
                  <Area type="monotone" dataKey="docs" stroke="#2563EB" fill="url(#docs)" strokeWidth={3} />
                  <Area type="monotone" dataKey="risks" stroke="#F59E0B" fill="transparent" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="space-y-5">
            {([
              [CalendarClock, 'Reminders', 'Court dates, renewals, agreement expiry, and custom notifications.'],
              [Languages, 'Language and accessibility', 'Plain-English explanations, translation modes, high contrast, ARIA labels, and keyboard-friendly controls.'],
              [LockKeyhole, 'Security posture', 'JWT-ready APIs, input validation, rate-limit hooks, secure upload checks, and environment-based secrets.'],
            ] as Array<[LucideIcon, string, string]>).map(([Icon, title, text]) => (
              <div key={title} className="rounded-3xl border border-white/80 bg-white p-5 shadow-lg shadow-slate-200/40 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
                <Icon className="h-6 w-6 text-[#F59E0B]" />
                <h3 className="mt-3 text-lg font-semibold">{title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-600 dark:text-slate-300">{text}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="chat" className="mx-auto max-w-7xl px-5 py-16">
          <div className="grid gap-5 lg:grid-cols-[0.35fr_0.65fr]">
            <aside className="rounded-3xl border border-white/80 bg-white p-5 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
              <h2 className="text-xl font-semibold">Saved Chats</h2>
              <div className="mt-4 space-y-3">
                {['Lease review', 'NDA questions', 'Draft legal notice'].map((title) => (
                  <button key={title} className="flex w-full items-center justify-between rounded-2xl bg-slate-50 px-4 py-3 text-left text-sm font-medium dark:bg-white/5">
                    {title}
                    <ChevronRight className="h-4 w-4" />
                  </button>
                ))}
              </div>
              <div className="mt-6 rounded-2xl bg-blue-50 p-4 text-sm leading-6 text-blue-950 dark:bg-blue-400/10 dark:text-blue-100">
                Conversations can be renamed, pinned, searched, deleted, exported, and saved to memory.
              </div>
            </aside>
            <div className="rounded-3xl border border-white/80 bg-white p-5 shadow-2xl shadow-blue-950/10 dark:border-white/10 dark:bg-white/10">
              <LegalDisclaimer />
              <div className="mt-5 h-[28rem] space-y-4 overflow-y-auto rounded-3xl bg-slate-50 p-4 dark:bg-slate-950/50">
                {chat.map((item, index) => (
                  <div key={`${item.from}-${index}`} className={`flex ${item.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[82%] rounded-3xl px-4 py-3 text-sm leading-6 ${item.from === 'user' ? 'bg-[#2563EB] text-white' : 'bg-white text-slate-700 shadow-sm dark:bg-white/10 dark:text-slate-100'}`}>
                      {item.text}
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {['Summarize this lease', 'Find risky clauses', 'Draft an NDA', 'Explain arbitration'].map((prompt) => (
                  <button key={prompt} onClick={() => setMessage(prompt)} className="rounded-full border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-600 dark:border-white/10 dark:bg-white/5 dark:text-slate-200">
                    {prompt}
                  </button>
                ))}
              </div>
              <form onSubmit={submitChat} className="mt-4 flex items-center gap-2 rounded-3xl border border-slate-200 bg-white p-2 shadow-sm dark:border-white/10 dark:bg-slate-950/60">
                <button type="button" aria-label="Voice input placeholder" className="rounded-2xl p-3 text-slate-500"><Mic className="h-5 w-5" /></button>
                <input value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Ask LexiAI about a document, clause, law, deadline, or draft..." className="min-w-0 flex-1 bg-transparent text-sm outline-none" />
                <button type="submit" aria-label="Send message" className="rounded-2xl bg-[#1E3A8A] p-3 text-white"><Send className="h-5 w-5" /></button>
              </form>
            </div>
          </div>
        </section>

        <section id="documents" className="mx-auto max-w-7xl px-5 py-16">
          <div className="grid gap-5 lg:grid-cols-3">
            <div className="rounded-3xl border-2 border-dashed border-blue-200 bg-white/80 p-8 text-center shadow-xl shadow-slate-200/50 dark:border-blue-400/30 dark:bg-white/10 dark:shadow-none">
              <UploadCloud className="mx-auto h-12 w-12 text-[#2563EB]" />
              <h2 className="mt-5 text-2xl font-semibold">Upload Documents</h2>
              <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">PDF, DOCX, and images with OCR, preview, progress, secure validation, delete controls, and virus-scan hooks.</p>
              <button onClick={() => toast.success('Upload workflow opened')} className="mt-6 rounded-full bg-[#2563EB] px-5 py-3 text-sm font-semibold text-white">Choose files</button>
            </div>
            <div className="rounded-3xl border border-white/80 bg-white p-6 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none lg:col-span-2">
              <h2 className="text-2xl font-semibold">Document Summary</h2>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {['Executive summary', 'Key points', 'Important dates', 'Parties involved', 'Obligations', 'Rights', 'Legal risks', 'Action items'].map((item) => (
                  <div key={item} className="flex items-center gap-3 rounded-2xl bg-slate-50 p-4 dark:bg-white/5">
                    <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                    <span className="text-sm font-semibold">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="research" className="mx-auto max-w-7xl px-5 py-16">
          <SectionTitle eyebrow="Research and generation" title="Search, bookmark, draft, export" text="LexiAI models research and drafting as agent-assisted workflows with editable outputs and PDF or DOCX export actions." />
          <div className="mt-10 grid gap-5 lg:grid-cols-2">
            <div className="rounded-3xl border border-white/80 bg-white p-6 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
              <Search className="h-7 w-7 text-[#2563EB]" />
              <h3 className="mt-4 text-xl font-semibold">Legal Research</h3>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {['Acts', 'Sections', 'Judgments', 'Topics', 'Bookmarks', 'Glossary'].map((item) => (
                  <button key={item} className="rounded-2xl bg-slate-50 p-4 text-left text-sm font-semibold dark:bg-white/5">{item}</button>
                ))}
              </div>
            </div>
            <div className="rounded-3xl border border-white/80 bg-white p-6 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
              <PenLine className="h-7 w-7 text-[#F59E0B]" />
              <h3 className="mt-4 text-xl font-semibold">Document Generator</h3>
              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                {['Rental Agreement', 'Employment Agreement', 'NDA', 'Legal Notice', 'Affidavit', 'Power of Attorney', 'Partnership Agreement', 'Will Template'].map((item) => (
                  <button key={item} className="rounded-2xl bg-slate-50 p-4 text-left text-sm font-semibold dark:bg-white/5">{item}</button>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="login" className="mx-auto max-w-7xl px-5 py-16">
          <div className="grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
            <div className="rounded-3xl bg-[#1E3A8A] p-8 text-white shadow-2xl shadow-blue-950/20">
              <Sparkles className="h-8 w-8 text-amber-300" />
              <h2 className="mt-5 text-3xl font-semibold">Profile, settings, and authentication</h2>
              <p className="mt-4 leading-7 text-blue-100">Firebase-ready email and Google login, forgot password, OTP verification, language, theme, security, notifications, photo, and logout workflows.</p>
              <div className="mt-8 space-y-3">
                {activity.map((item) => (
                  <div key={item} className="rounded-2xl bg-white/10 px-4 py-3 text-sm">{item}</div>
                ))}
              </div>
            </div>
            <form onSubmit={(event) => { event.preventDefault(); toast.success('Secure login flow ready') }} className="rounded-3xl border border-white/80 bg-white p-8 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
              <h2 className="text-2xl font-semibold">Welcome back</h2>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">Sign in to manage documents, saved chats, reminders, and AI usage.</p>
              <label className="mt-6 block text-sm font-semibold">Email</label>
              <input type="email" required className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] dark:border-white/10 dark:bg-slate-950/50" />
              <label className="mt-4 block text-sm font-semibold">Password</label>
              <input type="password" required className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 outline-none focus:border-[#2563EB] dark:border-white/10 dark:bg-slate-950/50" />
              <button className="mt-6 w-full rounded-2xl bg-[#1E3A8A] px-5 py-4 font-semibold text-white">Continue securely</button>
              <button type="button" className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl border border-slate-200 px-5 py-4 font-semibold dark:border-white/10">
                <Mail className="h-5 w-5" /> Continue with Google
              </button>
            </form>
          </div>
        </section>

        <section id="admin" className="mx-auto max-w-7xl px-5 py-16">
          <div className="rounded-3xl border border-white/80 bg-white p-6 shadow-xl shadow-slate-200/50 dark:border-white/10 dark:bg-white/10 dark:shadow-none">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-semibold">Admin Panel</h2>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">User management, AI usage, analytics, system logs, feedback, and document statistics.</p>
              </div>
              <UserRound className="h-8 w-8 text-[#2563EB]" />
            </div>
            <div className="mt-6 grid gap-3 md:grid-cols-3">
              {['Users monitored', 'AI requests audited', 'Feedback reviewed'].map((item, index) => (
                <div key={item} className="rounded-2xl bg-slate-50 p-5 dark:bg-white/5">
                  <p className="text-3xl font-semibold">{[1248, 8931, 317][index].toLocaleString()}</p>
                  <p className="mt-2 text-sm font-medium text-slate-500">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <footer className="border-t border-slate-200 bg-white/70 px-5 py-10 backdrop-blur dark:border-white/10 dark:bg-slate-950/70">
          <div className="mx-auto grid max-w-7xl gap-8 md:grid-cols-4">
            <div>
              <div className="flex items-center gap-3 text-xl font-semibold"><Gavel className="h-6 w-6 text-[#2563EB]" />LexiAI</div>
              <p className="mt-4 text-sm leading-6 text-slate-600 dark:text-slate-300">{disclaimer}</p>
            </div>
            {['About', 'Pricing', 'FAQ', 'Contact'].map((item) => (
              <div key={item}>
                <h3 className="font-semibold">{item}</h3>
                <p className="mt-3 text-sm leading-6 text-slate-600 dark:text-slate-300">Mission, vision, technology, team, support, location, and deployment-ready SaaS information.</p>
              </div>
            ))}
          </div>
        </footer>
      </main>
    </div>
  )
}

export const Route = createFileRoute('/')({
  component: App,
})
