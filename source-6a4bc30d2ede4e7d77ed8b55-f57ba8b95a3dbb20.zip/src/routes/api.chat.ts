import { createFileRoute } from '@tanstack/react-router'
import { chat, maxIterations, toServerSentEventsResponse } from '@tanstack/ai'
import { anthropicText } from '@tanstack/ai-anthropic'
import { geminiText } from '@tanstack/ai-gemini'
import { ollamaText } from '@tanstack/ai-ollama'
import { openaiText } from '@tanstack/ai-openai'

const SYSTEM_PROMPT = `You are LexiAI, an agentic AI legal information assistant.

You provide informational assistance only and are not a substitute for advice from a qualified lawyer. Include that disclaimer when answering legal questions.

AGENT WORKFLOW:
- Planner Agent: classify intent and route the task.
- Document Agent: extract and summarize document facts when text is supplied.
- Research Agent: retrieve relevant legal knowledge from available context.
- Risk Analysis Agent: identify risky clauses and missing protections.
- Drafting Agent: produce structured draft language when requested.
- Explanation Agent: convert legal language into plain English.
- Memory Agent: preserve user preferences and conversation context when available.
- Response Agent: combine outputs into a clear final answer.

CAPABILITIES:
- Summarize legal documents.
- Explain clauses in simple English.
- Detect risky termination, payment, penalty, confidentiality, liability, arbitration, renewal, and jurisdiction language.
- Draft templates such as NDAs, rental agreements, employment agreements, legal notices, affidavits, powers of attorney, partnership agreements, and will templates.
- Extract parties, dates, deadlines, obligations, rights, and action items.

RESPONSE RULES:
- Be clear, structured, and practical.
- Use tables when comparison helps.
- Do not claim to be a lawyer or provide definitive legal advice.
- Encourage review by a qualified lawyer for decisions with legal consequences.`

export const Route = createFileRoute('/api/chat')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const requestSignal = request.signal

        if (requestSignal.aborted) {
          return new Response(null, { status: 499 })
        }

        const abortController = new AbortController()

        try {
          const body = await request.json()
          const { messages } = body
          const data = body.data || {}

          let provider: 'anthropic' | 'openai' | 'gemini' | 'ollama' =
            data.provider || 'ollama'
          let model: string = data.model || 'mistral:7b'

          if (process.env.ANTHROPIC_API_KEY) {
            provider = 'anthropic'
            model = 'claude-haiku-4-5'
          } else if (process.env.OPENAI_API_KEY) {
            provider = 'openai'
            model = 'gpt-4o'
          } else if (process.env.GEMINI_API_KEY) {
            provider = 'gemini'
            model = 'gemini-2.0-flash-exp'
          }

          const adapterConfig = {
            anthropic: () => anthropicText((model || 'claude-haiku-4-5') as any),
            openai: () => openaiText((model || 'gpt-4o') as any),
            gemini: () => geminiText((model || 'gemini-2.0-flash-exp') as any),
            ollama: () => ollamaText((model || 'mistral:7b') as any),
          }

          const stream = chat({
            adapter: adapterConfig[provider](),
            tools: [],
            systemPrompts: [SYSTEM_PROMPT],
            agentLoopStrategy: maxIterations(4),
            messages,
            abortController,
          })

          return toServerSentEventsResponse(stream, { abortController })
        } catch (error: any) {
          console.error('LexiAI chat error:', error)
          if (error.name === 'AbortError' || abortController.signal.aborted) {
            return new Response(null, { status: 499 })
          }
          return new Response(
            JSON.stringify({
              error: 'Failed to process LexiAI chat request',
              message: error.message,
            }),
            {
              status: 500,
              headers: { 'Content-Type': 'application/json' },
            },
          )
        }
      },
    },
  },
})
