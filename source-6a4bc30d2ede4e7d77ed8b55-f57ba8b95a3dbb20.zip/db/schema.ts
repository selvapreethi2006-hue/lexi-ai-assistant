import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core'

export const users = pgTable('users', {
  id: serial().primaryKey(),
  firebaseUid: text('firebase_uid').notNull().unique(),
  name: text().notNull(),
  email: text().notNull().unique(),
  photoUrl: text('photo_url'),
  language: text().notNull().default('en'),
  theme: text().notNull().default('system'),
  role: text().notNull().default('user'),
  createdAt: timestamp('created_at').defaultNow(),
})

export const documents = pgTable('documents', {
  id: serial().primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text().notNull(),
  fileType: text('file_type').notNull(),
  storagePath: text('storage_path'),
  extractedText: text('extracted_text').notNull().default(''),
  summary: jsonb().notNull().default({}),
  riskScore: integer('risk_score').notNull().default(0),
  status: text().notNull().default('uploaded'),
  createdAt: timestamp('created_at').defaultNow(),
})

export const conversations = pgTable('conversations', {
  id: serial().primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text().notNull(),
  pinned: boolean().notNull().default(false),
  archived: boolean().notNull().default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
})

export const messages = pgTable('messages', {
  id: serial().primaryKey(),
  conversationId: integer('conversation_id').references(() => conversations.id),
  role: text().notNull(),
  content: text().notNull(),
  agentTrace: jsonb('agent_trace').notNull().default([]),
  createdAt: timestamp('created_at').defaultNow(),
})

export const reminders = pgTable('reminders', {
  id: serial().primaryKey(),
  userId: integer('user_id').references(() => users.id),
  title: text().notNull(),
  reminderType: text('reminder_type').notNull(),
  dueAt: timestamp('due_at').notNull(),
  status: text().notNull().default('scheduled'),
  createdAt: timestamp('created_at').defaultNow(),
})

export const feedback = pgTable('feedback', {
  id: serial().primaryKey(),
  userId: integer('user_id').references(() => users.id),
  rating: integer().notNull(),
  message: text().notNull(),
  createdAt: timestamp('created_at').defaultNow(),
})

export const auditLogs = pgTable('audit_logs', {
  id: serial().primaryKey(),
  actorId: integer('actor_id').references(() => users.id),
  action: text().notNull(),
  metadata: jsonb().notNull().default({}),
  createdAt: timestamp('created_at').defaultNow(),
})
