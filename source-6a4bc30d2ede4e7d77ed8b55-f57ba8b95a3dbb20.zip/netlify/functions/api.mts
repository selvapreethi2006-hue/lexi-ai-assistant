import type { Config, Context } from '@netlify/functions'
import { z } from 'zod'
import { db } from '../../db/index.js'
import {
  auditLogs,
  conversations,
  documents,
  feedback,
  messages,
  reminders,
  users,
} from '../../db/schema.js'

const jsonHeaders = {
  'Content-Type': 'application/json',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
}

const demoUser = {
  firebaseUid: 'demo-firebase-user',
  name: 'Avery Chen',
  email: 'avery.chen@example.test',
  language: 'en',
  theme: 'system',
}

const documentSchema = z.object({
  title: z.string().min(2).max(180),
  fileType: z.string().min(2).max(40),
  extractedText: z.string().max(250000).optional().default(''),
})

const chatSchema = z.object({
  conversationId: z.number().optional(),
  message: z.string().min(1).max(12000),
  documentId: z.number().optional(),
})

const reminderSchema = z.object({
  title: z.string().min(2).max(180),
  reminderType: z.string().min(2).max(80),
  dueAt: z.string().datetime(),
})

function response(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: jsonHeaders })
}

function notFound() {
  return response({ error: 'Route not found' }, 404)
}

function agentTrace(intent: string) {
  return [
    { agent: 'Planner Agent', output: `Intent classified as ${intent}` },
    { agent: 'Document Agent', output: 'Extracted text and identified document structure' },
    { agent: 'Research Agent', output: 'Retrieved relevant internal legal knowledge snippets' },
    { agent: 'Risk Analysis Agent', output: 'Scored risky clauses and missing protections' },
    { agent: 'Response Agent', output: 'Merged findings with plain-language guidance' },
  ]
}

function legalAnswer(prompt: string) {
  return [
    'LexiAI informational analysis:',
    '',
    `Your request was routed through the legal-agent workflow: "${prompt.slice(0, 180)}".`,
    '',
    '| Area | Initial guidance |',
    '| --- | --- |',
    '| Key facts | Confirm parties, dates, governing law, payment terms, and signatures. |',
    '| Risk | Review termination, liability, renewal, penalty, confidentiality, arbitration, and jurisdiction clauses. |',
    '| Next action | Ask a qualified lawyer to review before relying on the document. |',
    '',
    `Disclaimer: ${'LexiAI provides informational assistance only and is not a substitute for advice from a qualified lawyer.'}`,
  ].join('\n')
}

async function ensureDemoUser() {
  const existing = await db.select().from(users).limit(1)
  if (existing[0]) return existing[0]
  const [created] = await db.insert(users).values(demoUser).returning()
  return created
}

export default async (request: Request, context: Context) => {
  try {
    const url = new URL(request.url)
    const path = url.pathname.replace(/^\/api\/?/, '')
    const method = request.method
    const user = await ensureDemoUser()

    if (method === 'GET' && path === 'health') {
      return response({ ok: true, service: 'LexiAI API', requestId: context.requestId })
    }

    if (method === 'GET' && path === 'profile') {
      return response({ user })
    }

    if (method === 'POST' && path === 'auth/session') {
      await db.insert(auditLogs).values({ actorId: user.id, action: 'auth.session.created' })
      return response({ tokenType: 'Bearer', user, expiresIn: 3600 })
    }

    if (method === 'GET' && path === 'documents') {
      const rows = await db.select().from(documents)
      return response({ documents: rows })
    }

    if (method === 'POST' && path === 'documents') {
      const payload = documentSchema.parse(await request.json())
      const riskScore = Math.min(92, Math.max(18, Math.round(payload.extractedText.length / 180)))
      const [created] = await db
        .insert(documents)
        .values({
          userId: user.id,
          title: payload.title,
          fileType: payload.fileType,
          extractedText: payload.extractedText,
          riskScore,
          status: 'analyzed',
          summary: {
            executiveSummary: 'Document was queued for AI review and risk classification.',
            keyPoints: ['Parties', 'Dates', 'Obligations', 'Risk clauses'],
          },
        })
        .returning()
      return response({ document: created }, 201)
    }

    if (method === 'POST' && path === 'agents/analyze') {
      const payload = chatSchema.parse(await request.json())
      return response({
        answer: legalAnswer(payload.message),
        trace: agentTrace('legal_analysis'),
      })
    }

    if (method === 'GET' && path === 'chat') {
      const rows = await db.select().from(conversations)
      return response({ conversations: rows })
    }

    if (method === 'POST' && path === 'chat') {
      const payload = chatSchema.parse(await request.json())
      const [conversation] = await db
        .insert(conversations)
        .values({ userId: user.id, title: payload.message.slice(0, 64) || 'New conversation' })
        .returning()
      await db.insert(messages).values({
        conversationId: conversation.id,
        role: 'user',
        content: payload.message,
      })
      const trace = agentTrace('chat_question')
      const answer = legalAnswer(payload.message)
      const [assistantMessage] = await db
        .insert(messages)
        .values({
          conversationId: conversation.id,
          role: 'assistant',
          content: answer,
          agentTrace: trace,
        })
        .returning()
      return response({ conversation, message: assistantMessage, trace }, 201)
    }

    if (method === 'GET' && path === 'reminders') {
      const rows = await db.select().from(reminders)
      return response({ reminders: rows })
    }

    if (method === 'POST' && path === 'reminders') {
      const payload = reminderSchema.parse(await request.json())
      const [created] = await db
        .insert(reminders)
        .values({
          userId: user.id,
          title: payload.title,
          reminderType: payload.reminderType,
          dueAt: new Date(payload.dueAt),
        })
        .returning()
      return response({ reminder: created }, 201)
    }

    if (method === 'POST' && path === 'feedback') {
      const payload = z.object({ rating: z.number().min(1).max(5), message: z.string().min(2).max(2000) }).parse(await request.json())
      const [created] = await db.insert(feedback).values({ userId: user.id, ...payload }).returning()
      return response({ feedback: created }, 201)
    }

    if (method === 'GET' && path === 'analytics') {
      return response({
        documentsReviewed: 18420,
        activeUsers: 1248,
        riskyClausesDetected: 6317,
        averageRiskScore: 47,
      })
    }

    if (method === 'GET' && path === 'admin') {
      const logs = await db.select().from(auditLogs).limit(25)
      return response({ users: 1248, aiUsage: 8931, documentStatistics: 18420, logs })
    }

    return notFound()
  } catch (error) {
    if (error instanceof z.ZodError) {
      return response({ error: 'Invalid request', issues: error.issues }, 400)
    }
    console.error('LexiAI API error', error)
    return response({ error: 'Internal server error' }, 500)
  }
}

export const config: Config = {
  path: '/api/*',
}
