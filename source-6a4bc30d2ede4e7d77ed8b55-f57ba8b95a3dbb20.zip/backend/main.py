from fastapi import FastAPI

from agents.planner import plan_task

app = FastAPI(title="LexiAI Agent Backend", version="1.0.0")


@app.get("/health")
def health():
    return {"ok": True, "service": "LexiAI Agent Backend"}


@app.post("/agents/plan")
def plan(payload: dict):
    return plan_task(payload.get("message", ""))
