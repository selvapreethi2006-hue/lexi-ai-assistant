def search_knowledge(query: str) -> dict:
    return {"agent": "Research Agent", "query": query, "results": []}
