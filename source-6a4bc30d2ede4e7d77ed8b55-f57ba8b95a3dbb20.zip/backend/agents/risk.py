def analyze_risk(text: str) -> dict:
    risky_terms = ["penalty", "liability", "termination", "arbitration", "jurisdiction"]
    matches = [term for term in risky_terms if term in text.lower()]
    return {"agent": "Risk Analysis Agent", "matches": matches, "riskScore": min(95, len(matches) * 18)}
