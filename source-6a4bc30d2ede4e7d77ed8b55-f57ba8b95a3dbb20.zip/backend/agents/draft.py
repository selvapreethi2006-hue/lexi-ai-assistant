def draft_document(template: str, facts: dict) -> dict:
    return {"agent": "Drafting Agent", "template": template, "facts": facts, "status": "draft_ready"}
