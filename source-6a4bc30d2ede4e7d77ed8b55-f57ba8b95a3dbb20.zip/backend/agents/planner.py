def plan_task(message: str) -> dict:
    intent = "drafting" if "draft" in message.lower() else "legal_analysis"
    return {
        "agent": "Planner Agent",
        "intent": intent,
        "route": [
            "Document Agent",
            "Research Agent",
            "Risk Analysis Agent",
            "Response Agent",
        ],
    }
