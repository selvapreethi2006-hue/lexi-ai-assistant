def remember_context(user_id: str, preference: dict) -> dict:
    return {"agent": "Memory Agent", "userId": user_id, "preference": preference}
