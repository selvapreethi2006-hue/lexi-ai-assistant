def compose_response(parts: list[dict]) -> dict:
    return {"agent": "Response Agent", "parts": parts}
