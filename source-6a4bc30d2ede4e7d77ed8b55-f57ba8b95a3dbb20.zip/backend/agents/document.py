def extract_document_text(content: str) -> dict:
    return {"agent": "Document Agent", "text": content, "classification": "legal_document"}
