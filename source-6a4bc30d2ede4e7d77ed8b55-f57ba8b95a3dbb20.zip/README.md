# LexiAI

LexiAI is a production-oriented agentic AI legal information assistant. It helps users upload and summarize documents, explain clauses in plain English, identify risky contract language, draft legal templates, search legal knowledge, save chats, manage reminders, and review admin analytics.

LexiAI provides informational assistance only and is not a substitute for advice from a qualified lawyer.

## Key Technologies

- TanStack Start, React, TypeScript, Tailwind CSS
- Framer Motion, Lucide React, Recharts, React Hot Toast
- TanStack AI with OpenAI, Anthropic, Gemini, or Ollama adapters
- Netlify Functions for REST APIs
- Netlify Database with Drizzle ORM for persistent data
- Python FastAPI backend skeleton for the requested agent architecture

## Local Setup

Install dependencies:

```bash
npm install
```

Run the Netlify local environment:

```bash
/opt/buildhome/node-deps/node_modules/.bin/netlify dev --port 8889
```

## Environment Variables

Set these in Netlify or your local environment as needed. Do not commit secret values.

```bash
OPENAI_API_KEY=
DATABASE_URL=
SUPABASE_URL=
SUPABASE_KEY=
FIREBASE_CONFIG=
JWT_SECRET=
CHROMA_DB_PATH=
ANTHROPIC_API_KEY=
GEMINI_API_KEY=
```

Netlify Database is provisioned automatically and used through `@netlify/database`.

## Database

The schema is defined in `db/schema.ts`. Drizzle migrations are emitted to `netlify/database/migrations` and are applied by Netlify during deploy.

Generate a new migration after schema changes:

```bash
npx drizzle-kit generate
```

## Architecture

```text
User
  -> TanStack Start UI
  -> /api/chat streaming route for AI responses
  -> /api/* Netlify Function for REST resources
  -> Netlify Database via Drizzle
  -> Agent workflow: Planner -> Document -> Research -> Risk -> Drafting/Explanation -> Memory -> Response
```

## REST API Surface

- `POST /api/auth/session`
- `GET /api/profile`
- `GET /api/documents`
- `POST /api/documents`
- `GET /api/chat`
- `POST /api/chat`
- `POST /api/agents/analyze`
- `GET /api/reminders`
- `POST /api/reminders`
- `POST /api/feedback`
- `GET /api/analytics`
- `GET /api/admin`
- `GET /api/health`

## Deployment

- Frontend and Netlify Functions deploy through Netlify using `netlify.toml`.
- The Python FastAPI skeleton in `backend/` documents the requested Render-style backend shape and can be deployed separately if the project later splits services.
- Supabase Storage and Firebase Authentication are represented as integration-ready environment variables and UI/API surfaces.

## Screenshots

Add screenshots for:

- Landing page
- Dashboard
- Chat workspace
- Document upload and analysis
- Admin panel

## Contribution Guide

Keep UI components accessible, responsive, and keyboard navigable. Add database migrations with every schema change. Keep legal guidance framed as informational assistance and preserve the disclaimer on legal guidance screens.

## License

MIT
