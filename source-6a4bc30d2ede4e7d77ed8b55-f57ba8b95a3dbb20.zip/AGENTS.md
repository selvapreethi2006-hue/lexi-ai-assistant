# LexiAI Agent Notes

LexiAI is a TanStack Start and Netlify application with a polished React frontend, streaming AI chat route, serverless REST API, Drizzle schema, and a Python FastAPI agent skeleton.

## Key Directories

- `src/routes/index.tsx`: Main LexiAI product experience, including landing, dashboard, chat, documents, research, auth, profile, reminders, and admin surfaces.
- `src/routes/api.chat.ts`: Streaming TanStack AI chat endpoint with LexiAI legal-information system prompt.
- `netlify/functions/api.mts`: REST API for auth session, documents, chat, agents, reminders, profile, admin, analytics, and feedback.
- `db/schema.ts`: Netlify Database schema using Drizzle ORM.
- `netlify/database/migrations/`: Generated SQL migrations applied by Netlify.
- `backend/agents/`: Python agent skeleton matching the requested multi-agent architecture.

## Conventions

- Use TypeScript for deployed frontend and Netlify serverless code.
- Use Netlify Database for persistent application records.
- Do not store secrets in source files.
- Keep the legal disclaimer visible on pages that provide legal guidance.
- Prefer reusable, accessible controls with Lucide icons and Tailwind utility classes.

## Non-Obvious Decisions

The user requested a Next.js/Vercel plus FastAPI/Render stack, but this repository is a Netlify project with Netlify platform primitives required for persistence. The deployable implementation therefore uses TanStack Start, Netlify Functions, and Netlify Database while preserving the requested product capabilities and adding a Python backend skeleton for future service extraction.
